package com.cg.mobilebilling.stepdefinition;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ViewOpenPostpaidAcoountStepDefinition {
	private WebDriver driver;
	@Given("^User is on 'customerIndexPage' page$")
	public void user_is_on_customerIndexPage_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:8083/customer");
	}

	@When("^User clicks on 'Open Post-Paid Mobile Account' button$")
	public void user_clicks_on_Open_Post_Paid_Mobile_Account_button() throws Throwable {
	   driver.findElement(By.xpath("/html/body/div/div/table/tbody/tr[2]/td[2]/a/input")).click();
	}

	@Then("^'getOpenPostpaidMobileAccountPage\\.jsp' is loaded$")
	public void getopenpostpaidmobileaccountpage_jsp_is_loaded() throws Throwable {
	    assertEquals("Registration", driver.getTitle());
	    driver.close();
	}
}

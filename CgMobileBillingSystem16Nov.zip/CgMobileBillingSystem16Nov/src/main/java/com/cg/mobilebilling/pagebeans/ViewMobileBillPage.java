package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class ViewMobileBillPage {
	@FindBy(how=How.NAME,name="customerID")
	private WebElement customerID;
	@FindBy(how=How.NAME,name="mobileNo")
	private WebElement mobileNo;
	@FindBy(how=How.XPATH,xpath="/html/body/div/div/form/table/tbody/tr[3]/td/select")
	private WebElement billMonth;
	@FindBy(how=How.XPATH,xpath="/html/body/div/div/form/table/tbody/tr[4]/td[2]/input")
	private WebElement proceed;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"errorMessage\"]/h3")
	private WebElement actualErrorMessage;
	public ViewMobileBillPage() {}
	public String getCustomerID() {
		return customerID.getAttribute("value");
	}
	public void setCustomerID(String customerID) {
		this.customerID.sendKeys(customerID);;
	}
	public String getMobileNo() {
		return mobileNo.getAttribute("value");
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}
	public String getBillMonth() {
		return billMonth.getAttribute("value");
	}
	public void setBillMonth(String billMonth) {
		this.billMonth.sendKeys(billMonth);
	}
	public String getActualErrorMessage() {
		return actualErrorMessage.getText().toString();
	}
	public void proceedAction() {
		this.proceed.click();
	}
	
}

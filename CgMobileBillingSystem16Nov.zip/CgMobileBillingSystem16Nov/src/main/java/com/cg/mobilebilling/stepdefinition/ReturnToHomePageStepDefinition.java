package com.cg.mobilebilling.stepdefinition;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ReturnToHomePageStepDefinition {
	/*private WebDriver driver;
	@Given("^User is on 'displayAllPlanDetailsPage\\.jsp' page$")
	public void user_is_on_displayAllPlanDetailsPage_jsp_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://localhost:8083/allPlanDetails");
		//driver.manage().window().maximize();
	}

	@When("^User clicks on 'return to home page' link$")
	public void user_clicks_on_return_to_home_page_link() throws Throwable {
	    
		driver.findElement(By.xpath("/html/body/div/div/div/a")).click();
	}
	@When("^User clicks on 'return  home page' link$")
	public void user_clicks_on_return_home_page_link() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"success\"]/div/a")).click();
	}
	@Then("^'indexPage\\.jsp' is loaded$")
	public void indexpage_jsp_is_loaded() throws Throwable {
	   String actualString=driver.getTitle();
	   String expectedString="Capgemini";
	   Assert.assertEquals(expectedString, actualString);
	   driver.close();
	}

	@Given("^User is on 'customerIndexPage\\.jsp' page$")
	public void user_is_on_customerIndexPage_jsp_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://localhost:8083/customer");
	}

	@Given("^User is on 'adminIndexPage\\.jsp' page$")
	public void user_is_on_adminIndexPage_jsp_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://localhost:8083/admin");
	}*/
}

package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegisterNewCustomerPage {
	@FindBy(how=How.XPATH, xpath="//*[@id=\"firstName\"]")
	private WebElement firstName;
	@FindBy(how=How.XPATH, xpath="//*[@id=\"lastName\"]")
	private WebElement LastName;
	@FindBy(how=How.XPATH, xpath="//*[@id=\"emailID\"]")
	private WebElement emailID;
	@FindBy(how=How.XPATH, xpath="//*[@id=\"dateOfBirth\"]")
	private WebElement dateOfBirth;
	@FindBy(how=How.XPATH, xpath="//*[@id=\"billingAddress.city\"]")
	private WebElement city;
	@FindBy(how=How.XPATH, xpath="//*[@id=\"billingAddress.pinCode\"]")
	private WebElement pinCode;
	@FindBy(how=How.XPATH, xpath="//*[@id=\"billingAddress.state\"]")
	private WebElement state;
	@FindBy(how=How.XPATH,xpath="/html/body/div/div/table/tbody/tr[8]/td[2]/input")
	private WebElement submit; 
	public RegisterNewCustomerPage() {}
	public String getFirstName() {
		return firstName.getAttribute("value");
	}
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}
	public String getLastName() {
		return LastName.getAttribute("value");
	}
	public void setLastName(String lastName) {
		this.LastName.sendKeys(lastName);
	}
	public String getEmailID() {
		return emailID.getAttribute("value");
	}
	public void setEmailID(String emailID) {
		this.emailID.sendKeys(emailID);
	}
	public String getDateOfBirth() {
		return dateOfBirth.getAttribute("value");
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth.sendKeys(dateOfBirth);
	}
	public String getCity() {
		return city.getAttribute("value");
	}
	public void setCity(String city) {
		this.city.sendKeys(city);
	}
	public String getPinCode() {
		return pinCode.getAttribute("value");
	}
	public void setPinCode(String pinCode) {
		this.pinCode.sendKeys(pinCode);
	}
	public String getState() {
		return state.getAttribute("value");
	}
	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public void clickSignIn() {
		submit.click();
	}
	
	
	
}

package com.cg.mobilebilling.pagebeans;

import static org.assertj.core.api.Assertions.in;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class GenerateMonthlyBillPage {
	@FindBy(how=How.NAME,name="customerID")
	private WebElement customerID;
	@FindBy(how=How.NAME,name="mobileNo")
	private WebElement mobileNo;
	@FindBy(how=How.NAME,name="billMonth")
	private WebElement billMonth;
	@FindBy(how=How.NAME,name="noOfLocalSMS")
	private WebElement noOfLocalSMS;
	@FindBy(how=How.NAME,name="noOfLocalCalls")
	private WebElement noOfLocalCalls;
	@FindBy(how=How.NAME,name="noOfStdSMS")
	private WebElement noOfStdSMS;
	@FindBy(how=How.NAME,name="noOfStdCalls")
	private WebElement noOfStdCalls;
	@FindBy(how=How.NAME,name="internetDataUsageUnits")
	private WebElement internetDataUsageUnits;
	@FindBy(how=How.XPATH,xpath="/html/body/div/div/form/table/tbody/tr[9]/td[2]/input")
	private WebElement button;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"errorMessage\"]/h3")
	private WebElement actualErrorMessage;
	public GenerateMonthlyBillPage() {}
	public String getCustomerID() {
		return customerID.getAttribute("value");
	}
	public void setCustomerID(String customerID) {
		this.customerID.sendKeys(customerID);;
	}
	public String getMobileNo() {
		return mobileNo.getAttribute("value");
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}
	public String getBillMonth() {
		return billMonth.getAttribute("value");
	}
	public void setBillMonth(String billMonth) {
		this.billMonth.sendKeys(billMonth);
	}
	public String getNoOfLocalSMS() {
		return noOfLocalSMS.getAttribute("value");
	}
	public void setNoOfLocalSMS(String noOfLocalSMS) {
		this.noOfLocalSMS.sendKeys(noOfLocalSMS);
	}
	public String getNoOfLocalCalls() {
		return noOfLocalCalls.getAttribute("value");
	}
	public void setNoOfLocalCalls(String noOfLocalCalls) {
		this.noOfLocalCalls.sendKeys(noOfLocalCalls);
	}
	public String getNoOfStdSMS() {
		return noOfStdSMS.getAttribute("value");
	}
	public void setNoOfStdSMS(String noOfStdSMS) {
		this.noOfStdSMS.sendKeys(noOfStdSMS);
	}
	public String getNoOfStdCalls() {
		return noOfStdCalls.getAttribute("value");
	}
	public void setNoOfStdCalls(String noOfStdCalls) {
		this.noOfStdCalls.sendKeys(noOfStdCalls);
	}
	public String getInternetDataUsageUnits() {
		return internetDataUsageUnits.getAttribute("value");
	}
	public void setInternetDataUsageUnits(String internetDataUsageUnits) {
		this.internetDataUsageUnits.sendKeys(internetDataUsageUnits);
	}
	public void setButton() {
		button.click();
	}
	public String getActualErrorMessage() {
		return actualErrorMessage.getText().toString();
	}
	
	
}	

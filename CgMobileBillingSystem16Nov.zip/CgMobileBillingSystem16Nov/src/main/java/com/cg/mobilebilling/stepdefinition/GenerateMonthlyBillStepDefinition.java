package com.cg.mobilebilling.stepdefinition;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.GenerateMonthlyBillPage;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GenerateMonthlyBillStepDefinition {
	private WebDriver driver;
	private GenerateMonthlyBillPage details;
	@Given("^Customer is on 'getGenerateMonthlyMobileBillPage\\.jsp'$")
	public void customer_is_on_getGenerateMonthlyMobileBillPage_jsp() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:8083/generateMonthlyMobileBill");
		details=PageFactory.initElements(driver, GenerateMonthlyBillPage.class);
	}

	@When("^Customer enters  valid information to generate Bill$")
	public void customer_enters_valid_information_to_generate_Bill() throws Throwable {
	    details.setCustomerID("1001");
	    details.setMobileNo("905904276");
	    details.setBillMonth("April");
	    details.setNoOfLocalSMS("125");
	    details.setNoOfLocalCalls("200");
	    details.setNoOfStdSMS("125");
	    details.setNoOfStdCalls("150");
	    details.setInternetDataUsageUnits("1500");
	    details.setButton();
	}

	@Then("^Customer should be directed to 'displayMonthlyMobileBillPage\\.jsp'$")
	public void customer_should_be_directed_to_displayMonthlyMobileBillPage_jsp() throws Throwable {
	    assertEquals("Success", driver.getTitle());
	    driver.close();
	}
}	

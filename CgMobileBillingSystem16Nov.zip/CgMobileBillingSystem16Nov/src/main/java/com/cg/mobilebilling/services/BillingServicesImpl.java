package com.cg.mobilebilling.services;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServices;
import com.cg.mobilebilling.daoservices.CustomerDAOServices;
import com.cg.mobilebilling.daoservices.PlanDAOServices;
import com.cg.mobilebilling.daoservices.PostpaidAccountDAOServices;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
@Component("billingServices")
public class BillingServicesImpl implements BillingServices {
		
	@Autowired
	private PlanDAOServices planDAOService;
	@Autowired
	private CustomerDAOServices customerDAOService;
	@Autowired
	private PostpaidAccountDAOServices postpaidAccountDAOService;
	@Autowired
	private BillingDAOServices billingDAOServices;
	static int COUNTER=0;
	
	public BillingServicesImpl() {
		super();
	}
	public BillingServicesImpl(PlanDAOServices planDAOService) {
		super();
		this.planDAOService=planDAOService;
	}
	public BillingServicesImpl(CustomerDAOServices customerDAOService) {
		super();
		this.customerDAOService=customerDAOService;
	}
	public BillingServicesImpl(PostpaidAccountDAOServices postpaidAccountDAOService) {
		super();
		this.postpaidAccountDAOService=postpaidAccountDAOService;
	}
	public BillingServicesImpl(BillingDAOServices billingDAOServices) {
		super();
		this.billingDAOServices=billingDAOServices;
	}
	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {
		if(COUNTER<1) {
				Plan plan=new Plan(150, 100, 100, 100, 100, 1024, 0.1f, 0.1f, 1.0f, 1.0f, 1.0f, "pune", "offer");
				planDAOService.save(plan);
				plan=new Plan(250, 200, 200, 200, 200, 2048, 0.1f, 0.1f, 1.0f, 1.0f, 1.0f, "pune", "Super offer");
				planDAOService.save(plan);
				plan=new Plan(50, 50, 50, 50, 50, 1024, 0.1f, 0.1f, 1.0f, 1.0f, 1.0f, "pune", "Diwali offer");
				planDAOService.save(plan);
				plan=new Plan(100, 75, 75, 75, 75, 1024, 0.1f, 0.1f, 1.0f, 1.0f, 1.0f, "pune", "Super saver pack");
				planDAOService.save(plan);
				plan=new Plan(500, 500, 500, 500, 500, 5128, 0.1f, 0.1f, 1.0f, 1.0f, 1.0f, "pune", "Jumbo pack");
				planDAOService.save(plan);
				COUNTER++;
			}
		List<Plan> listPlan=planDAOService.findAll();
		return listPlan;
	}

	@Override
	public int acceptCustomerDetails(Customer customer)
			throws BillingServicesDownException {
		customer=customerDAOService.save(customer);
		return customer.getCustomerID();
	}

	@Override
	public long openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAOService.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer not found"));
		Plan plan=planDAOService.findById(planID).orElseThrow(()->new PlanDetailsNotFoundException("Enter valid plan"));
		PostpaidAccount postpaidAccount=new PostpaidAccount(customer,plan);
		postpaidAccount=postpaidAccountDAOService.save(postpaidAccount);
		return postpaidAccount.getMobileNo();
	}

	@Override
	public int generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillingServicesDownException, PlanDetailsNotFoundException {
		Customer customer = customerDAOService.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Not found"));
		Map<Long, PostpaidAccount>  postpaidAccounts= customer.getPostpaidAccounts();
		for(Long key:postpaidAccounts.keySet()) {
			if(key==mobileNo) {
				PostpaidAccount postpaidAccount=postpaidAccounts.get(key);
				Plan plan=postpaidAccount.getPlan();
				if(plan==null)
					throw new PlanDetailsNotFoundException("Plan details not found.");
				Map<Integer, Bill> bills=postpaidAccount.getBills();
				for (Integer key1 : bills.keySet()) {
					Bill billMonthCheck=bills.get(key1);
					if(billMonthCheck.getBillMonth().equals(billMonth))
						throw new InvalidBillMonthException("Bill Already Generated");
				}
				int localSMSAmount=0,stdSMSAmount=0,localCallAmount=0,stdCallAmount=0,internetDataUsageAmount=0,monthlyRental=0,billAmount=0,servicesTax=0,vat=0,totalBillAmount=0;
				if(noOfLocalSMS>plan.getFreeLocalSMS())
					localSMSAmount = (int) ((noOfLocalSMS-plan.getFreeLocalSMS())*plan.getLocalSMSRate());
				
				if(noOfLocalCalls>plan.getFreeLocalCalls())
					localCallAmount=(int) ((noOfLocalCalls-plan.getFreeLocalCalls())*plan.getLocalCallRate());
				
				if(noOfStdSMS>plan.getFreeStdSMS())
					stdSMSAmount=(int) ((noOfStdSMS-plan.getFreeStdSMS())*plan.getStdSMSRate());
				
				if(noOfStdCalls>plan.getFreeStdCalls())
					stdCallAmount=(int) ((noOfStdCalls-plan.getFreeStdCalls())*plan.getStdCallRate());
				
				if(internetDataUsageUnits>plan.getFreeInternetDataUsageUnits())
					internetDataUsageAmount=(int) ((internetDataUsageUnits-plan.getFreeInternetDataUsageUnits())*plan.getInternetDataUsageRate());
				
				monthlyRental= plan.getMonthlyRental();
				billAmount=monthlyRental+localSMSAmount+stdSMSAmount+localCallAmount+stdCallAmount+internetDataUsageAmount;
				servicesTax=(int)billAmount*10/100;
				vat=(int)billAmount*5/100;
				totalBillAmount = billAmount+servicesTax+vat;
				
				Bill bill=new Bill(noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits, billMonth, totalBillAmount, localSMSAmount, stdSMSAmount, localCallAmount, stdCallAmount, internetDataUsageAmount, servicesTax, vat, postpaidAccount);
				bill=billingDAOServices.save(bill);
				return totalBillAmount;
			}
		}
		//PostpaidAccount postpaidAccount = postpaidAccountDAOService.findById(mobileNo).orElseThrow(()->new PostpaidAccountNotFoundException("Postpaid Account not found"));
		throw new PostpaidAccountNotFoundException();
		
	}

	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		return customerDAOService.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer not found"));
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
		return customerDAOService.findAll();
	}

	/*@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		PostpaidAccount postpaidAccount = postpaidAccountDAOService.findById(mobileNo).get();
		if(postpaidAccount==null)
			throw new PostpaidAccountNotFoundException();
		return postpaidAccount;
	}*/

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer = customerDAOService.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer not found"));
		 Map<Long,PostpaidAccount> customers= customer.getPostpaidAccounts();
		List<PostpaidAccount> postpaidAccounts =new ArrayList<>(customers.values());
		 return postpaidAccounts;
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException, BillingServicesDownException, PlanDetailsNotFoundException {
		customerDAOService.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer not found"));
		postpaidAccountDAOService.findById(mobileNo).orElseThrow(()->new PlanDetailsNotFoundException("Postpaid Account not found"));
		Bill bill = billingDAOServices.getMonthlyBill(mobileNo,billMonth);
		if(bill==null)
			throw new InvalidBillMonthException("Invalid Bill Month");
		return bill;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			BillDetailsNotFoundException, PlanDetailsNotFoundException {
		customerDAOService.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer not found"));
		postpaidAccountDAOService.findById(mobileNo).orElseThrow(()->new PlanDetailsNotFoundException("Postpaid Account not found"));
		List<Bill> bills=billingDAOServices.getCustomerPostPaidAccountAllBills(mobileNo);
		if(bills==null)
			throw new BillDetailsNotFoundException("Bill not found");
		return bills;
	}

	@Override
	public int changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException,
			PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAOService.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer Not Found"));
		Map<Long, PostpaidAccount> postpaidAccounts=customer.getPostpaidAccounts();
		
		postpaidAccountDAOService.findById(mobileNo).orElseThrow(()->new PlanDetailsNotFoundException("Postpaid Account not found"));
		planDAOService.findById(planID).orElseThrow(()->new PlanDetailsNotFoundException("Invalid plan"));
		return postpaidAccountDAOService.changePlan(planID, mobileNo);
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, PlanDetailsNotFoundException {
		customerDAOService.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer not found"));
		postpaidAccountDAOService.findById(mobileNo).orElseThrow(()->new PlanDetailsNotFoundException("Postpaid Account not found"));
		billingDAOServices.deleteByMobileNo(mobileNo);
		postpaidAccountDAOService.removeMobileNo(mobileNo);
		return true;
	}

	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException {
		customerDAOService.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer not found"));
		customerDAOService.deleteById(customerID);
		return true;
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
		customerDAOService.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer not found"));
		PostpaidAccount postpaidAccount=postpaidAccountDAOService.findById(mobileNo).orElseThrow(()->new PlanDetailsNotFoundException("Postpaid Account not found"));
		Plan plan=postpaidAccount.getPlan();
		if(plan==null)
			throw new PlanDetailsNotFoundException();
		return plan;
	}
}
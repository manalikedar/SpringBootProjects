package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class ViewCustomerDetailsPage {
	@FindBy(how=How.NAME,name="customerID")
	private WebElement customerID;
	@FindBy(how=How.XPATH,xpath="//*[@id=\"errorMessage\"]/h3")
	private WebElement actualErrorMessage;
	@FindBy(how=How.XPATH,xpath="/html/body/div/div/form/table/tbody/tr[2]/td[2]/input")
	private WebElement proceed;
	public ViewCustomerDetailsPage() {}
	public String getCustomerID() {
		return customerID.getAttribute("value");
	}
	public void setCustomerID(String customerID) {
		this.customerID.sendKeys(customerID);;
	}
	public String getActualErrorMessage() {
		return actualErrorMessage.getText().toString();
	}
	public void proceedAction() {
		proceed.click();
	}
	
	
}

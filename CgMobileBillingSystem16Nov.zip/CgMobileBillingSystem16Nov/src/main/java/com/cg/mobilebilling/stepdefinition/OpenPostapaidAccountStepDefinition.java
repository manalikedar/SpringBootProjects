package com.cg.mobilebilling.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.mobilebilling.pagebeans.OpenPostapaidAccountPage;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OpenPostapaidAccountStepDefinition {
	private WebDriver driver;
	private OpenPostapaidAccountPage postpaidAccount;
	@Given("^Customer is on 'getOpenPostpaidMobileAccountPage\\.jsp'$")
	public void customer_is_on_getOpenPostpaidMobileAccountPage_jsp() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:8083/openPostpaidMobileAccount");
		postpaidAccount=PageFactory.initElements(driver, OpenPostapaidAccountPage.class);
	}

	@When("^Customer enters  valid information$")
	public void customer_enters_valid_information() throws Throwable {
	    postpaidAccount.setCustomerID("1001");
	    postpaidAccount.setPlanID("1");
	    postpaidAccount.clickSubmit();
	}

	@Then("^Customer should be directed to 'accountOpeningSuccessPage\\.jsp'$")
	public void customer_should_be_directed_to_accountOpeningSuccessPage_jsp() throws Throwable {
	   Assert.assertEquals("Success", driver.getTitle());
	   driver.close();
	}

	@When("^Customer enters  invalid account information$")
	public void customer_enters_invalid_account_information() throws Throwable {
		postpaidAccount.setCustomerID("11");
	    postpaidAccount.setPlanID("1");
	    postpaidAccount.clickSubmit();
	}

	@Then("^Message \"([^\"]*)\" is displayed on customerIndexPage$")
	public void message_is_displayed_on_customerIndexPage(String arg1) throws Throwable {
		Assert.assertEquals("Customer Not Found!!!!!Please Register", postpaidAccount.getActualErrorMessage());
		driver.close();
	}

	@When("^Customer enters  invalid Plan information$")
	public void customer_enters_invalid_Plan_information() throws Throwable {
		postpaidAccount.setCustomerID("1001");
	    postpaidAccount.setPlanID("10");
	    postpaidAccount.clickSubmit();
	}
	@Then("^Messages \"([^\"]*)\" is displayed on customerIndexPage$")
	public void messages_is_displayed_on_customerIndexPage(String arg1) throws Throwable {
		Assert.assertEquals("Invalid Plan!!!!!Please Try Again", postpaidAccount.getActualErrorMessage());
		driver.close();
	}
}

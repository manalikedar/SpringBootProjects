package com.cg.mobilebilling.pagebeans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class OpenPostapaidAccountPage {
		@FindBy(how=How.NAME,name="customerID")
		private WebElement customerID;
		@FindBy(how=How.NAME,name="planID")
		private WebElement planID;
		@FindBy(how=How.CLASS_NAME,name="submit")
		private WebElement submit;
		@FindBy(how=How.XPATH,xpath="//*[@id=\"errorMessage\"]/h3")
		private WebElement actualErrorMessage;
		public OpenPostapaidAccountPage() {}
		public String getCustomerID() {
			return customerID.getAttribute("value");
		}
		public void setCustomerID(String customerID) {
			this.customerID.sendKeys(customerID);
		}
		public String getPlanID() {
			return planID.getAttribute("value");
		}
		public void setPlanID(String planID) {
			this.planID.sendKeys(planID);
		}
		public String getActualErrorMessage() {
			return actualErrorMessage.getText().toString();
		}
		public void setActualErrorMessage(String actualErrorMessage) {
			this.actualErrorMessage.sendKeys(actualErrorMessage);;
		}
		public void clickSubmit() {
			submit.click();
		}
		
		
}

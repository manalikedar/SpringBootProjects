package com.cg.mobilebilling.stepdefinition;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.CustomerAllPostPaidAccountsDetailsPage;
import com.cg.mobilebilling.pagebeans.GenerateMonthlyBillPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CustomerAllPostPaidAccountsDetailsStepDefinition {
	private WebDriver driver;
	private CustomerAllPostPaidAccountsDetailsPage details;	
	@Given("^Customer is on 'getCustomerAllPostpaidAccountsDetailsPage'$")
	public void customer_is_on_getCustomerAllPostpaidAccountsDetailsPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:8083/customerAllPostpaidAccountsDetails");
		details=PageFactory.initElements(driver, CustomerAllPostPaidAccountsDetailsPage.class);
	}
	@When("^Customer enters valid Customer ID$")
	public void customer_enters_valid_Customer_ID() throws Throwable {
		details.setCustomerID("1001");
		details.proceedAction();
	}

	@Then("^Postpaid account details of that customer are displayed on 'displayCustomerAllPostpaidAccountsDetailsPage'$")
	public void postpaid_account_details_of_that_customer_are_displayed_on_displayCustomerAllPostpaidAccountsDetailsPage() throws Throwable {
		assertEquals("All Post-Paid Accounts", driver.getTitle());
		driver.close();
	}

	@When("^Customer enters invalid Customer ID$")
	public void customer_enters_invalid_Customer_ID() throws Throwable {
		details.setCustomerID("1");
		details.proceedAction();
	}

	@Then("^Error message is displayed on 'customerIndexPage'$")
	public void error_message_is_displayed_on_customerIndexPage() throws Throwable {
		assertEquals("Customer Not Found!!!!!Please Register", details.getActualErrorMessage());
		driver.close();
	}
}

package com.cg.mobilebilling.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ViewCustomerStepDefinition {
	private WebDriver driver;
	@Given("^User is on 'customerIndexPage'$")
	public void user_is_on_customerIndexPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:8083/customer");
	}

	@When("^Customer clicks on 'View Customer' button$")
	public void customer_clicks_on_View_Customer_button() throws Throwable {
		driver.findElement(By.xpath("/html/body/div/div/table/tbody/tr[3]/td[1]/a/input")).click();
	}

	@Then("^'customerDetailsPAge' should open$")
	public void customerdetailspage_should_open() throws Throwable {
		Assert.assertEquals("Customer", driver.getTitle());
		driver.close();
	}
}

package com.cg.mobilebilling.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ViewAdminStepDefinition {
	private WebDriver driver;
	@Given("^Admin is on 'indexPage'$")
	public void admin_is_on_indexPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:8083/");
	}

	@When("^Admin clicks on 'Admin' button$")
	public void admin_clicks_on_Admin_button() throws Throwable {
		driver.findElement(By.xpath("/html/body/div/div/table/tbody/tr[2]/td[3]/a/input")).click();
	}

	@Then("^Admin should be directed to 'adminIndexPage'$")
	public void admin_should_be_directed_to_adminIndexPage() throws Throwable {
		String actualString=driver.getTitle();
		String expectedString="Admin";
		Assert.assertEquals(expectedString, actualString);
		driver.close();
	}
}

package com.cg.mobilebilling.stepdefinition;

import org.junit.Assert;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.RegisterNewCustomerPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class RegisterNewCustomerStepDefinition {
	private WebDriver driver;
	private RegisterNewCustomerPage customer;
	@Given("^User is on 'customerIndexPage\\.jsp' page$")
	public void user_is_on_customerIndexPage_jsp_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:8083/register");
		customer=PageFactory.initElements(driver, RegisterNewCustomerPage.class);
	}

	@When("^User clicks on 'Register New Customer' button$")
	public void user_clicks_on_Register_New_Customer_button() throws Throwable {
		//driver.findElement(By.xpath("/html/body/div/div/table/tbody/tr[2]/td[1]/a/input")).click();   
		
	}

	@When("^Enter Valid Details$")
	public void enter_Valid_Details() throws Throwable {
		customer.setFirstName("Manali");
		customer.setLastName("Kedar");
		customer.setEmailID("mkedar@gmail.com");
		customer.setDateOfBirth("12-05-1996");
		customer.setCity("Pune");
		customer.setState("Maharashtra");
		customer.setPinCode("44007");
		customer.clickSignIn();	 
	}

	@Then("^'registrationSuccessPage' is loaded$")
	public void registrationsuccesspage_is_loaded() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Success";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}
}

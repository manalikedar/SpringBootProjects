package com.cg.mobilebilling.stepdefinition;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ViewAllPlansStepDefinition {
	/*private WebDriver driver;
	@Given("^User is on MobileBillingSystem Home Page$")
	public void user_is_on_MobileBillingSystem_Home_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:8083/");
		//driver.manage().window().maximize();
	}

	@When("^User Clicks on 'View All Plans' Button$")
	public void user_Clicks_on_View_All_Plans_Button() throws Throwable {
		driver.findElement(By.xpath("/html/body/div/div/table/tbody/tr[2]/td[1]/a/input")).click();
	}

	@Then("^'displayAllPlanDetailsPage' loads$")
	public void displayallplandetailspage_loads() throws Throwable {
		String actualString=driver.getTitle();
		String expectedString="Plans";
		Assert.assertEquals(expectedString, actualString);
		driver.close();
	}*/
}

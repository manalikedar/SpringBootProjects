package com.cg.mobilebilling.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ViewCustomerIndexPageStepDefinition {
	/*private WebDriver driver;
	@Given("^User is on MobileBillingSystem Home Page$")
	public void user_is_on_MobileBillingSystem_Home_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:8083/");
	}

	@When("^User Clicks on 'Customer' Button$")
	public void user_Clicks_on_Customer_Button() throws Throwable {
		driver.findElement(By.xpath("/html/body/div/div/table/tbody/tr[2]/td[2]/a/input")).click();
	}

	@Then("^'customerIndexPage\\.jsp' is loaded$")
	public void customerindexpage_jsp_is_loaded() throws Throwable {
		String actualString=driver.getTitle();
		String expectedString="Customer";
		Assert.assertEquals(expectedString, actualString);
		driver.close();
	}*/
}

package com.cg.mobilebilling.stepdefinition;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.RegisterNewCustomerPage;
import com.cg.mobilebilling.pagebeans.ViewCustomerDetailsPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ViewCustomerDetailsStepDefinition {
	private WebDriver driver;
	private ViewCustomerDetailsPage details;
	@Given("^Customer is on 'viewCustomerPage'$")
	public void customer_is_on_viewCustomerPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:8083/customerDetails");
		details=PageFactory.initElements(driver, ViewCustomerDetailsPage.class);
	}

	@When("^Customer enters valid customer ID$")
	public void customer_enters_valid_customer_ID() throws Throwable {
	    details.setCustomerID("1001");
	    details.proceedAction();
	}

	@Then("^Customer Personal details are displayed on 'displayCustomerDetailsPage'$")
	public void customer_Personal_details_are_displayed_on_displayCustomerDetailsPage() throws Throwable {
	    assertEquals("Customer Details", driver.getTitle());
	    driver.close();
	}

	@When("^Customer enter invalid customer ID$")
	public void customer_enter_invalid_customer_ID() throws Throwable {
		details.setCustomerID("1");
		details.proceedAction();
	}

	@Then("^Error Message is displayed on 'customerIndexPage'$")
	public void error_Message_is_displayed_on_customerIndexPage() throws Throwable {
	    assertEquals("Customer Not Found!!!!!Please Register", details.getActualErrorMessage());
	    driver.close();
	}

}

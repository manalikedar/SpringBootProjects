package com.cg.mobilebilling.stepdefinition;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilebilling.pagebeans.ViewMobileBillPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class viewMobileBillStepDefintion {
	private WebDriver driver;
	private ViewMobileBillPage details;
	@Given("^Customer will be on 'customerIndexPage'$")
	public void customer_will_be_on_customerIndexPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\softwares\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:8083/customer");
		details=PageFactory.initElements(driver, ViewMobileBillPage.class);
	}

	@When("^Customer clicks on 'View Mobile Bill' button$")
	public void customer_clicks_on_View_Mobile_Bill_button() throws Throwable {
	   driver.findElement(By.xpath("/html/body/div/div/table/tbody/tr[3]/td[3]/a/input"));
	}

	@When("^Enter valid details for cutomer id, mobile number and month$")
	public void enter_valid_details_for_cutomer_id_mobile_number_and_month() throws Throwable {
	    details.setCustomerID("1001");
	    details.setMobileNo("905904276");
	    details.setBillMonth("January");
	    details.proceedAction();
	}

	@Then("^Mobile bill for that month is dialpayed on 'displayMonthlyBillPage'$")
	public void mobile_bill_for_that_month_is_dialpayed_on_displayMonthlyBillPage() throws Throwable {
	    assertEquals("Bill", driver.getTitle());
	    driver.close();
	}

	@When("^Enter invalid details for cutomer id and valid mobile number and month$")
	public void enter_invalid_details_for_cutomer_id_and_valid_mobile_number_and_month() throws Throwable {
		details.setCustomerID("1");
	    details.setMobileNo("905904276");
	    details.setBillMonth("January");
	    details.proceedAction();
	}

	@Then("^Customer Error Message is displayed on 'customerIndexPage'$")
	public void customer_Error_Message_is_displayed_on_customerIndexPage() throws Throwable {
	    assertEquals("Customer Not Found!!!!!Please Register", details.getActualErrorMessage());
	    driver.close();
	}

	@When("^Enter valid details for cutomer id, month and invalid mobile number$")
	public void enter_valid_details_for_cutomer_id_month_and_invalid_mobile_number() throws Throwable {
		details.setCustomerID("1001");
	    details.setMobileNo("905664276");
	    details.setBillMonth("January");
	    details.proceedAction();
	}

	@Then("^Mobile number Error Message is displayed on 'customerIndexPage''$")
	public void mobile_number_Error_Message_is_displayed_on_customerIndexPage() throws Throwable {
		assertEquals("Invalid Mobile Number!!!!!Please Try Again", details.getActualErrorMessage());
	    driver.close();
	}

	@When("^Enter valid details for cutomer id, mobile number and invalid month$")
	public void enter_valid_details_for_cutomer_id_mobile_number_and_invalid_month() throws Throwable {
		details.setCustomerID("1001");
	    details.setMobileNo("905904276");
	    details.setBillMonth("December");
	    details.proceedAction();
	}

	@Then("^Month Error Message is displayed on 'customerIndexPage'$")
	public void month_Error_Message_is_displayed_on_customerIndexPage() throws Throwable {
		assertEquals("Invalid Bill Month!!!!!Please Try Again", details.getActualErrorMessage());
	    driver.close();
	}
}

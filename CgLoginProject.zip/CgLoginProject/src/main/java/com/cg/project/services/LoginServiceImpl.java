package com.cg.project.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.project.daoservices.UserDAO;
@Component("loginServices")
public class LoginServiceImpl implements LoginService {
	@Autowired
	UserDAO userDao;
	@Override
	public boolean validateUser(String userid, String password) {
		return userid.equalsIgnoreCase("manali")
				&& password.equalsIgnoreCase("dummy");

	}
}

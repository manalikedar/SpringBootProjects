package com.cg.project.services;

public interface LoginService {
	public boolean validateUser(String userid, String password) ;
}

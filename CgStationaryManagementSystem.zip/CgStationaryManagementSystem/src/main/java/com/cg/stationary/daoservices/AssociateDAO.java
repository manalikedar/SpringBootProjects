package com.cg.stationary.daoservices;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.stationary.beans.Associate;

@Qualifier("JpaRepository")
public interface AssociateDAO extends JpaRepository<Associate, Integer>{

}

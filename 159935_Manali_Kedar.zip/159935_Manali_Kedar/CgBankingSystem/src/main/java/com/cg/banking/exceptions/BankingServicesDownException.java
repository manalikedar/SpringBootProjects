package com.cg.banking.exceptions;
@SuppressWarnings("serial")
public class BankingServicesDownException extends Exception {

}

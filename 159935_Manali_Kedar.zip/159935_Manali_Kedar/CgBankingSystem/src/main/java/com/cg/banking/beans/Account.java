package com.cg.banking.beans;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
@Entity
@SequenceGenerator(name="seqAccount")
public class Account {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE ,generator="seqAccount")
	private long accountNo;
	private String accountType;
	private float accountBalance;
	@ManyToOne
	private Customer customer;
	@OneToMany(mappedBy="account", cascade=CascadeType.ALL,fetch = FetchType.EAGER)
	private  List<Transaction> transaction;
	public Account() {
		super();
	}
	public Account(String accountType, float accountBalance) {
		super();
		this.accountType = accountType;
		this.accountBalance = accountBalance;
	}
	public Account(long accountNo,String accountType, float accountBalance) {
		super();
		this.accountNo=accountNo;
		this.accountType = accountType;
		this.accountBalance = accountBalance;
	}
	public Account(String accountType, float accountBalance, Customer customer) {
		super();
		this.accountType = accountType;
		this.accountBalance = accountBalance;
		this.customer = customer;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public float getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}
	public List<Transaction> getTransaction() {
		return transaction;
	}
	public void setTransaction(List<Transaction> transaction) {
		this.transaction = transaction;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountType="
				+ accountType + ", accountBalance=" + accountBalance+", transaction=" + transaction
				+ "]";
	}
}
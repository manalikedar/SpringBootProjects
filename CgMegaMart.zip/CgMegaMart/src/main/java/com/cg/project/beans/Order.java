package com.cg.project.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.Table;

@Entity
@Table(name="product_order")
public class Order {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int orderID;
	@ManyToOne
	@MapKey
	@JoinColumn(name="customerID")
	private Customer customer;
	@ManyToOne
	@MapKey
	@JoinColumn(name="productID")
	private Product product;
	int count;
	/**
	 * 
	 */
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * @param orderID
	 * @param customer
	 * @param product
	 * @param count
	 */
	public Order(int orderID, Customer customer, Product product, int count) {
		super();
		this.orderID = orderID;
		this.customer = customer;
		this.product = product;
		this.count = count;
	}

	/**
	 * @param customer
	 * @param product
	 * @param count
	 */
	public Order(Customer customer, Product product, int count) {
		super();
		this.customer = customer;
		this.product = product;
		this.count = count;
	}

	public int getOrderID() {
		return orderID;
	}
	public void setOrderID(int orderID) {
		this.orderID = orderID;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + count;
		result = prime * result + ((customer == null) ? 0 : customer.hashCode());
		result = prime * result + orderID;
		result = prime * result + ((product == null) ? 0 : product.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Order other = (Order) obj;
		if (count != other.count)
			return false;
		if (customer == null) {
			if (other.customer != null)
				return false;
		} else if (!customer.equals(other.customer))
			return false;
		if (orderID != other.orderID)
			return false;
		if (product == null) {
			if (other.product != null)
				return false;
		} else if (!product.equals(other.product))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Order [orderID=" + orderID + ", customer=" + customer + ", product=" + product + ", count=" + count
				+ "]";
	}
	
}

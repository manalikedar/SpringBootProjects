package com.cg.project.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.project.beans.Customer;
import com.cg.project.beans.Order;
import com.cg.project.beans.Product;

@Controller
public class URIController {
	Customer customer;
	Order order;
	Product product;
	@ModelAttribute
	public Customer getCustomer() {
		customer=new Customer();
		return customer;
	}
	@ModelAttribute
	public Order getOrder() {
		order=new Order();
		return order;
	}
	@ModelAttribute
	public Product getProduct() {
		product=new Product();
		return product;
	}
	@RequestMapping(value= {"/","/home","/indexPage"})
	public String getIndexPage() {
		System.out.println("Here");
		return "indexPage";
	}
	@RequestMapping(value="/customer")
	public String openCustomerIndexPage() {
		return "customerIndexPage";
	}
	@RequestMapping(value="/registerPage")
	public String getRegisterCustomerPage() {
		return "registerPage";
	}
	@RequestMapping(value="/loginPage")
	public String getCustomerLoginPage() {
		return "loginPage";
	}
	@RequestMapping(value="/customerHomePage")
	public String getCustomerHomePage() {
		return "customerHomePage";
	}
}

package com.cg.project.services;

import java.util.List;

import com.cg.project.beans.Customer;
import com.cg.project.beans.Order;
import com.cg.project.beans.Product;
import com.cg.project.exceptions.ProductNotFoundException;
import com.cg.project.exceptions.CustomerNotFoundException;
import com.cg.project.exceptions.IncorrectProductNameException;
import com.cg.project.exceptions.MegaMartServicesDownException;
import com.cg.project.exceptions.OrderNotFoundException;
import com.cg.project.exceptions.ProductAlreadyExistsException;



public interface MegaMartServices {
	public Customer registerCustomer(Customer customer) throws MegaMartServicesDownException;
	
	public List<Product> viewAllProducts() throws MegaMartServicesDownException, ProductNotFoundException;
	public Order orderProduct(Order order) throws MegaMartServicesDownException,CustomerNotFoundException,ProductNotFoundException;
	public List<Order> viewCustomerAllOrders(int customerID) throws MegaMartServicesDownException,CustomerNotFoundException,OrderNotFoundException;
	public int addItemToList(Product product)throws MegaMartServicesDownException, ProductAlreadyExistsException;
	public void updateProductList(Product product)throws MegaMartServicesDownException, ProductNotFoundException, IncorrectProductNameException;
	public void deleteProductFromList(Product product)throws MegaMartServicesDownException, ProductNotFoundException;
	public List<Order> viewAllOrders()throws MegaMartServicesDownException, OrderNotFoundException;
	public void cancelOrder(int customerID,int orderID)throws MegaMartServicesDownException, CustomerNotFoundException, OrderNotFoundException;
	
}

package com.cg.project.daoservices;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.project.beans.Product;
@Qualifier("JpaRepository")
public interface ProductDAO extends JpaRepository<Product, Integer>{

}

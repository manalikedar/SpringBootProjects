package com.cg.project.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.cg.project.beans.Customer;
import com.cg.project.beans.Order;
import com.cg.project.beans.Product;
import com.cg.project.exceptions.CustomerNotFoundException;
import com.cg.project.exceptions.MegaMartServicesDownException;
import com.cg.project.services.MegaMartServices;

@Controller
@SessionAttributes("name")
public class MegaMartController {
	@Autowired
	private MegaMartServices megaMartServices;
	Customer customer;
	Order order;
	Product product;
	
	@RequestMapping(value="/registerCustomer")
	public ModelAndView registerCustomerAction(@Valid@ModelAttribute Customer customer,BindingResult bindingResultCustomer) {
		if(bindingResultCustomer.hasErrors())
			return new ModelAndView("registerPage");
		Customer registeredCustomer;
		try {
			registeredCustomer=megaMartServices.registerCustomer(customer);
		}catch(MegaMartServicesDownException e) {
			return new ModelAndView("registerPage","errorMessage","Error Occured!!! Please try later");
		}
		return new ModelAndView("registrationSuccessPage","customer",customer);
	}
	
	@RequestMapping(value="/validateUser")
	public ModelAndView validateUserAction(@RequestParam("customerID") int customerID,@RequestParam("password") String password) throws CustomerNotFoundException,MegaMartServicesDownException{
		try {
			if(megaMartServices.validateCustomer(customerID, password))
			return new ModelAndView("customerHomePage");
			else
				throw new CustomerNotFoundException();
		}catch (CustomerNotFoundException e) {
			String message = "Invalid User Name or Password";
			return new ModelAndView("loginPage","errorMessage",message);
		}catch(MegaMartServicesDownException e) {
			String message="Services Down!!! Please Try Later";
			return new ModelAndView("customer","errorMessage",message);
		}
		
	}
}

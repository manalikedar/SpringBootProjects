package com.cg.project.controllers;

import org.springframework.stereotype.Controller;

import com.cg.project.beans.Customer;
import com.cg.project.beans.Order;
import com.cg.project.beans.Product;

@Controller
public class MegaMartController {
	
	Customer customer;
	Order order;
	Product product;
}

package com.cg.project.beans;

import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;

@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int customerID;
	private String customerName;
	private Long mobileNo;
	@Embedded
	private Address address;
	@OneToMany(mappedBy="customer",cascade=CascadeType.ALL,fetch=FetchType.EAGER)
	@MapKey
	Map<Integer, Order> orders;
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	/**
	 * @param customerName
	 * @param mobileNo
	 * @param address
	 * @param orders
	 */
	public Customer(String customerName, Long mobileNo, Address address, Map<Integer, Order> orders) {
		super();
		this.customerName = customerName;
		this.mobileNo = mobileNo;
		this.address = address;
		this.orders = orders;
	}
	/**
	 * @param customerID
	 * @param customerName
	 * @param mobileNo
	 * @param address
	 * @param orders
	 */
	public Customer(int customerID, String customerName, Long mobileNo, Address address, Map<Integer, Order> orders) {
		super();
		this.customerID = customerID;
		this.customerName = customerName;
		this.mobileNo = mobileNo;
		this.address = address;
		this.orders = orders;
	}
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Map<Integer, Order> getOrders() {
		return orders;
	}
	public void setOrders(Map<Integer, Order> orders) {
		this.orders = orders;
	}
	@Override
	public String toString() {
		return "Customer [customerID=" + customerID + ", customerName=" + customerName + ", mobileNo=" + mobileNo
				+ ", address=" + address + ", orders=" + orders + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + customerID;
		result = prime * result + ((customerName == null) ? 0 : customerName.hashCode());
		result = prime * result + ((mobileNo == null) ? 0 : mobileNo.hashCode());
		result = prime * result + ((orders == null) ? 0 : orders.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (customerID != other.customerID)
			return false;
		if (customerName == null) {
			if (other.customerName != null)
				return false;
		} else if (!customerName.equals(other.customerName))
			return false;
		if (mobileNo == null) {
			if (other.mobileNo != null)
				return false;
		} else if (!mobileNo.equals(other.mobileNo))
			return false;
		if (orders == null) {
			if (other.orders != null)
				return false;
		} else if (!orders.equals(other.orders))
			return false;
		return true;
	}
	
	
	
}

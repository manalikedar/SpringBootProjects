package com.cg.project.exceptions;

public class MegaMartServicesDownException extends Exception{

	/**
	 * 
	 */
	public MegaMartServicesDownException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 * @param enableSuppression
	 * @param writableStackTrace
	 */
	public MegaMartServicesDownException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public MegaMartServicesDownException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public MegaMartServicesDownException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public MegaMartServicesDownException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}

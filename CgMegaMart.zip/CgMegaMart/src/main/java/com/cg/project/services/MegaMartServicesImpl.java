package com.cg.project.services;

import java.util.List;

import com.cg.project.beans.Customer;
import com.cg.project.beans.Order;
import com.cg.project.beans.Product;
import com.cg.project.exceptions.CustomerNotFoundException;
import com.cg.project.exceptions.IncorrectProductNameException;
import com.cg.project.exceptions.MegaMartServicesDownException;
import com.cg.project.exceptions.OrderNotFoundException;
import com.cg.project.exceptions.ProductAlreadyExistsException;
import com.cg.project.exceptions.ProductNotFoundException;

public class MegaMartServicesImpl implements MegaMartServices{

	@Override
	public Customer registerCustomer(Customer customer) throws MegaMartServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> viewAllProducts() throws MegaMartServicesDownException, ProductNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Order orderProduct(Order order)
			throws MegaMartServicesDownException, CustomerNotFoundException, ProductNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Order> viewCustomerAllOrders(int customerID)
			throws MegaMartServicesDownException, CustomerNotFoundException, OrderNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int addItemToList(Product product) throws MegaMartServicesDownException, ProductAlreadyExistsException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void updateProductList(Product product)
			throws MegaMartServicesDownException, ProductNotFoundException, IncorrectProductNameException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteProductFromList(Product product) throws MegaMartServicesDownException, ProductNotFoundException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Order> viewAllOrders() throws MegaMartServicesDownException, OrderNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void cancelOrder(int customerID, int orderID)
			throws MegaMartServicesDownException, CustomerNotFoundException, OrderNotFoundException {
		// TODO Auto-generated method stub
		
	}

}

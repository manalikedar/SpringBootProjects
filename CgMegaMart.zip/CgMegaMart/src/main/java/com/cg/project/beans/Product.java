package com.cg.project.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Product {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int productID;
	private String productName;
	private int unitsAvailable;
	private float price;
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Product(String productName, int unitsAvailable, float price) {
		super();
		this.productName = productName;
		this.unitsAvailable = unitsAvailable;
		this.price = price;
	}
	public Product(int productID, String productName, int unitsAvailable, float price) {
		super();
		this.productID = productID;
		this.productName = productName;
		this.unitsAvailable = unitsAvailable;
		this.price = price;
	}
	public int getProductID() {
		return productID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getUnitsAvailable() {
		return unitsAvailable;
	}
	public void setUnitsAvailable(int unitsAvailable) {
		this.unitsAvailable = unitsAvailable;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(price);
		result = prime * result + productID;
		result = prime * result + ((productName == null) ? 0 : productName.hashCode());
		result = prime * result + unitsAvailable;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (Float.floatToIntBits(price) != Float.floatToIntBits(other.price))
			return false;
		if (productID != other.productID)
			return false;
		if (productName == null) {
			if (other.productName != null)
				return false;
		} else if (!productName.equals(other.productName))
			return false;
		if (unitsAvailable != other.unitsAvailable)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Product [productID=" + productID + ", productName=" + productName + ", unitsAvailable=" + unitsAvailable
				+ ", price=" + price + "]";
	}
	
}

package com.cg.project.daoservices;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.project.beans.Customer;
@Qualifier("JpaRepository")
public interface CustomerDAO extends JpaRepository<Customer, Integer>{

}

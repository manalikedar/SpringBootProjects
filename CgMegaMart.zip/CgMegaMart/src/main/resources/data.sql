insert into product (price,product_name,units_available) values(20,'Maggie',100);
insert into product (price,product_name,units_available) values(10,'Biscuit',100);
insert into product (price,product_name,units_available) values(50,'Surf Excel',100);
insert into product (price,product_name,units_available) values(17,'Salt',100);
insert into product (price,product_name,units_available) values(35,'Pepper',100);
insert into product (price,product_name,units_available) values(32,'Wafers',100);
